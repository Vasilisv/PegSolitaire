
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Game a = new Game();

Game.main(args);
Peg p = new Peg();
Game.DFS(p);
	}

}
